import { useEffect, useState, useMemo, memo } from "react";
import { useQuiz } from "../context/QuizContext";

const SECS_PER_QUESTIONS = 30;

const Timer = memo(() => {
  // const { finishTimeHandler } = useQuiz();
  const [questions, setQuestions] = useState([]);
  useEffect(() => {
    async function feteQuestions() {
      const response = await fetch(
        "https://65818f8f3dfdd1b11c439954.mockapi.io/questions"
      );
      const data = await response.json();
      setQuestions(data);
    }
    feteQuestions();
  }, []);
  const [secondsRemaining, setSecondsRemaining] = useState(
    questions.length * SECS_PER_QUESTIONS || 0
  );
  useEffect(() => {
    if (questions) setSecondsRemaining(questions.length * SECS_PER_QUESTIONS);
  }, [questions]);

  const tick = () => {
    // if (secondsRemaining === 0) return finishTimeHandler();
    setSecondsRemaining((prev) => prev - 1);
  };

  const timeDisplay = useMemo(() => {
    const mins = Math.floor(secondsRemaining / 60);
    const seconds = secondsRemaining % 60;
    return `${mins < 10 ? "0" : ""}${mins}:${
      seconds < 10 ? "0" : ""
    }${seconds}`;
  }, [secondsRemaining]);

  useEffect(() => {
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [tick]);

  return <div className='timer'>{timeDisplay}</div>;
});

export default Timer;
